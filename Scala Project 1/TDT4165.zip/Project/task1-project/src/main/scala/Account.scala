class Account(initialBalance: Double, val uid: Int = Bank getUniqueId) {
  def withdraw(amount: Double): Unit = ??? // Implement
  def deposit(amount: Double): Unit = ??? // Implement
  def getBalanceAmount: Double = ??? // Implement
}
